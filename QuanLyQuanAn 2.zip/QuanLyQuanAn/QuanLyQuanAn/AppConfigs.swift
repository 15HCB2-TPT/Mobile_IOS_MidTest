//
//  AppConfigs.swift
//  QuanLyQuanAn
//
//  Created by Hiroshi.Kazuo on 4/20/17.
//  Copyright © 2017 Shin-MacDesk. All rights reserved.
//

struct AppConfigs {
    static let LANGUAGE_KEY = "lanKey"
    static let CURRENCY_KEY = "curKey"
}
