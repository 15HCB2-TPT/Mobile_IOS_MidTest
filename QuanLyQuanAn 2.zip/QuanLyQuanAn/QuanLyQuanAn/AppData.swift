//
//  AppData.swift
//  QuanLyQuanAn
//
//  Created by Hiroshi.Kazuo on 4/20/17.
//  Copyright © 2017 Shin-MacDesk. All rights reserved.
//

struct AppData {
    //static var AppLanguage:
    static var AppCurrency: Currency?
}
