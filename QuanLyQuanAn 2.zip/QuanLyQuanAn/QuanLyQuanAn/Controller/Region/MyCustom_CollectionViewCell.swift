//
//  MyCustom_CollectionViewCell.swift
//  QuanLyQuanAn
//
//  Created by Shin-MacDesk on 4/10/17.
//  Copyright © 2017 Shin-MacDesk. All rights reserved.
//

import UIKit

class MyCustom_CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var viewlayer: UIView!
    @IBOutlet weak var btn_restore: UIButton!
    @IBOutlet weak var btn_infor: UIButton!
    @IBOutlet weak var image_region: UIImageView!
    @IBOutlet weak var label_nameregion: UILabel!
}
