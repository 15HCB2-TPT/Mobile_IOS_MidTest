//
//  Table_Pay_Cell.swift
//  QuanLyQuanAn
//
//  Created by Hiroshi.Kazuo on 4/20/17.
//  Copyright © 2017 Shin-MacDesk. All rights reserved.
//

import UIKit

class Table_Pay_Cell: UITableViewCell{
    
    // MARK: **** Elements ****
    @IBOutlet weak var imgFood: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var moneyDetails: UILabel!
    
}
